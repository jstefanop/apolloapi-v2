const store = require('./store')

module.exports = store
