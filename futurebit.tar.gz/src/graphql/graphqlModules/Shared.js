module.exports.typeDefs = `
  enum SortOrder { asc, desc }
`
